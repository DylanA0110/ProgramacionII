﻿
using BinaryAdapters;

string fileName = "personas.bin";

IPersonBinary repository = new PersonBinaryRepository(fileName);

repository.Add(new Person { Name = "Dylan", Age = 18, Height = 1.79M });
repository.Add(new Person { Name = "Estrella", Age = 17, Height = 1.35M });
repository.Add(new Person { Name = "Jared", Age = 18, Height = 1.77M });
repository.Add(new Person { Name = "Axel", Age = 18, Height = 1.75M });

 void Imprimir()
{
    foreach (var persona in repository.GetAll())
    {
        Console.WriteLine($"{Environment.NewLine}ID: {persona.Id}, Name: {persona.Name}, Age: {persona.Age}, Height: {persona.Height}");
    }
}

Imprimir();
repository.Update(new Person { Id = 2, Name = "Estrella", Height = 1.55M, Age = 17 });

var person =  repository.GetPerson(1);
Console.WriteLine($"{person.Name} con ID: {person.Id}");


repository.Delete(3);

