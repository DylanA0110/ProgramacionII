﻿using System.Net.Http.Headers;

string texto = "Este es un ejemplo2";

File.WriteAllText("ejemplo.txt", texto);

string texto2 = File.ReadAllText("ejemplo.txt");
Console.WriteLine($"Texto leído del archivo: {texto2}");

//Adaptador

int[] numeros = { 1, 2, 3, 4, 5, 6, 7, 8, };

using(BinaryWriter br = new BinaryWriter(File.Open("numeros.bin", FileMode.Create)))
{
    foreach(var num in numeros)
    {
        br.Write(num); 
    }
}

int[] numerosLeidos;
//Leer datos
using (BinaryReader br = new BinaryReader(File.Open("numeros.bin", FileMode.Open)))
{
    numerosLeidos = new int[numeros.Length];
    for (int i = 0; i < numerosLeidos.Length; i++)
        numerosLeidos[i] = br.ReadInt32();
}

Console.WriteLine("Numeros leidos desde el archivo binario :");

foreach(var num in numerosLeidos) 
    Console.WriteLine(num);



